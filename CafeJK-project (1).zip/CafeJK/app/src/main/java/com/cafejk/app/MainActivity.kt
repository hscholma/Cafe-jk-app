package com.cafejk.app

import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.UUID

@SuppressLint("MissingPermission", "SetJavaScriptEnabled")
class MainActivity : Activity() {

    private lateinit var web: WebView
    private val uuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private val main = Handler(Looper.getMainLooper())
    private var serverStarted = false

    private fun adapter(): BluetoothAdapter? =
        (getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter

    private fun hasPerm(): Boolean =
        Build.VERSION.SDK_INT < 31 ||
            checkSelfPermission("android.permission.BLUETOOTH_CONNECT") == PackageManager.PERMISSION_GRANTED

    private fun js(code: String) {
        runOnUiThread { web.evaluateJavascript(code, null) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        if (Build.VERSION.SDK_INT >= 31 && !hasPerm()) {
            requestPermissions(arrayOf("android.permission.BLUETOOTH_CONNECT"), 1)
        }

        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(), "Android")

        val root = FrameLayout(this)
        root.setBackgroundColor(0xFFFBF6EE.toInt())
        root.addView(web, FrameLayout.LayoutParams(-1, -1))
        root.setOnApplyWindowInsetsListener { v, insets ->
            @Suppress("DEPRECATION")
            v.setPadding(
                insets.systemWindowInsetLeft,
                insets.systemWindowInsetTop,
                insets.systemWindowInsetRight,
                insets.systemWindowInsetBottom
            )
            insets
        }
        setContentView(root)
        web.loadUrl("file:///android_asset/index.html")
    }

    // De terugknop van Android doet niets, zodat de app niet per ongeluk sluit.
    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
    }

    /** Medewerker-tablet: wacht op bestellingen. */
    private fun serve() {
        val a = adapter() ?: return
        while (true) {
            var ss: android.bluetooth.BluetoothServerSocket? = null
            try {
                val server = a.listenUsingRfcommWithServiceRecord("CafeJK", uuid)
                ss = server
                while (true) {
                    val s = server.accept()
                    try {
                        val line = BufferedReader(InputStreamReader(s.inputStream, Charsets.UTF_8)).readLine()
                        if (line != null) {
                            js("window.btReceive(" + JSONObject.quote(line) + ")")
                            s.outputStream.write("OK\n".toByteArray(Charsets.UTF_8))
                            s.outputStream.flush()
                            Thread.sleep(300)
                        }
                    } catch (e: Exception) {
                    } finally {
                        try { s.close() } catch (e: Exception) {}
                    }
                }
            } catch (e: Exception) {
                try { ss?.close() } catch (x: Exception) {}
                try { Thread.sleep(1500) } catch (x: InterruptedException) {}
            }
        }
    }

    inner class Bridge {

        @JavascriptInterface
        fun status(): String {
            val a = adapter() ?: return "none"
            if (!hasPerm()) return "perm"
            if (!a.isEnabled) return "off"
            return "ok"
        }

        @JavascriptInterface
        fun pairedDevices(): String {
            val arr = JSONArray()
            try {
                adapter()?.bondedDevices?.forEach { d ->
                    arr.put(JSONObject().put("name", d.name ?: "").put("address", d.address))
                }
            } catch (e: Exception) {
            }
            return arr.toString()
        }

        @JavascriptInterface
        fun startServer() {
            synchronized(this@MainActivity) {
                if (serverStarted) return
                serverStarted = true
            }
            Thread { serve() }.start()
        }

        @JavascriptInterface
        fun send(id: String, address: String, json: String) {
            Thread {
                var sock: BluetoothSocket? = null
                var closer: Runnable? = null
                var ok = false
                var msg = ""
                try {
                    val a = adapter() ?: throw Exception("geen Bluetooth")
                    val s = a.getRemoteDevice(address).createRfcommSocketToServiceRecord(uuid)
                    sock = s
                    val c = Runnable { try { s.close() } catch (e: Exception) {} }
                    closer = c
                    main.postDelayed(c, 15000)
                    s.connect()
                    s.outputStream.write((json + "\n").toByteArray(Charsets.UTF_8))
                    s.outputStream.flush()
                    val reply = BufferedReader(InputStreamReader(s.inputStream, Charsets.UTF_8)).readLine()
                    ok = reply == "OK"
                    if (!ok) msg = "geen bevestiging ontvangen"
                } catch (e: Exception) {
                    msg = e.message ?: "verbinding mislukt"
                } finally {
                    closer?.let { main.removeCallbacks(it) }
                    try { sock?.close() } catch (e: Exception) {}
                }
                js("window.btSendResult(" + JSONObject.quote(id) + "," + ok + "," + JSONObject.quote(msg) + ")")
            }.start()
        }
    }
}
